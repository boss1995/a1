import {Component,OnInit} from '@angular/core';
import {FormsModule,NgForm }  from '@angular/forms';
import {Mobile} from './mobile.component';
import {Myservice} from './myservice'
@Component({
    selector:"my-form",
    templateUrl:'./myform.component.html',
    providers :[Myservice]
})
export class MyForm implements OnInit{
    mob:Mobile;


    mobList:Mobile[]=[];

    constructor(private mser:Myservice){
        this.mob ={mobId:0,mobName:"",mobPrice:0};
    }
    ngOnInit(){
       
        this.mser.getAllMob().subscribe(result=>this.mobList=result);

    }
  
    
//function to sort Mobile Id in ascending order    
     id1(){
        this.mobList.sort(function(a,b){return a.mobId-b.mobId});
        }
    
//function to sort Mobile Name in ascending order      
     id2(){
        this.mobList.sort(function(a,b){
            if(a.mobName<b.mobName)
            return -1;
        else if(a.mobName>b.mobName)   
            return 1;   
            else return 0;
        });
        }
        
//Function to sort Mobile Price    
     id3(){
        this.mobList.sort(function(a,b){return a.mobPrice-b.mobPrice});
        }
      
    
// Function For deleting any row   
       deleteFunction(mobId:any){

    for(var i=0;i<this.mobList.length;i++)
    {
        if(this.mobList[i]["mobId"]==mobId)    
  this.mobList.splice(i,1);
  }
    }
  
    
}