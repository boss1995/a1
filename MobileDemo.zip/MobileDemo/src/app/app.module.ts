import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }  from '@angular/forms';
import { AppComponent }  from './app.component';
import { MyForm }  from './myform.component';
import {HttpModule} from '@angular/http';
import {DemoPipe} from './demopipe'


@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule ],
  declarations: [ AppComponent,MyForm,DemoPipe ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
