package com.cg.hotel.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="hoteldetails")
public class Hotellll {
	
	@Id
	@Column(name="id")
	
	private int hotelbookid;
	
	@Column(name="name")
	private String customerName;
	
	
	private String rating;
	
	private int rate;
	
	private int availablerooms;
	
	public Hotellll() {
	
	}

	

	public int getHotelbookid() {
		return hotelbookid;
	}



	public void setHotelbookid(int hotelbookid) {
		this.hotelbookid = hotelbookid;
	}



	

	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}



	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getAvailablerooms() {
		return availablerooms;
	}

	public void setAvailablerooms(int availablerooms) {
		this.availablerooms = availablerooms;
	}

}
