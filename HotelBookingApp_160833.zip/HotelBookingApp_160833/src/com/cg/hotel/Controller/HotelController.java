package com.cg.hotel.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;






import com.cg.hotel.bean.Hotellll;
import com.cg.hotel.bean.HotelBook;
import com.cg.hotel.service.IhotelService;


@Controller
public class HotelController {
	@Autowired
	IhotelService ihbs;
	@RequestMapping("home")
	public String gohome(Model model)
	{
		
		List<Hotellll> hotellist = ihbs.getHotels();
		model.addAttribute("hotellist", hotellist);
		model.addAttribute("bh", new HotelBook());
		
		return "BookingDetails";
		
	}
	
	
	
	@RequestMapping("register")
	public String hotelregister(@ModelAttribute("bh")  @Valid HotelBook bh, BindingResult res, Model model)
	{
		if(res.hasErrors()){
			List<Hotellll> hotellist = ihbs.getHotels();
		
			model.addAttribute("bh", bh);
			
			return "BookingDetails";
			
		}
else{
			
			long hotelbookid= ihbs.hotelBook(bh);
			model.addAttribute("hotelbookid", hotelbookid);
			return "BookingConfirmation";
		}
	

	}

}