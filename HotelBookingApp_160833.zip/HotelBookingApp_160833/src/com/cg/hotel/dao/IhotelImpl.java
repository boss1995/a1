package com.cg.hotel.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;





import org.springframework.stereotype.Repository;

import com.cg.hotel.bean.Hotellll;
import com.cg.hotel.bean.HotelBook;


@Repository
public class IhotelImpl implements Ihotel {
	
	@PersistenceContext
	EntityManager hman;

	@Override
	public long hotelBook(HotelBook bh) {
		
		 hman.persist(bh);
		
		return bh.getHotelbookid();
	}
	@Override
	public List<Hotellll> getHotels() {
		String sql= "SELECT  hotellll FROM Hotellll hotellll";
		TypedQuery<Hotellll> hotelquery =   hman.createQuery(sql,Hotellll.class);
		
		return hotelquery.getResultList();
	}
}
