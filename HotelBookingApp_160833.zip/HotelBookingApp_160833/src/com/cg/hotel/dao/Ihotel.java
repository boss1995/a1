package com.cg.hotel.dao;


import java.util.List;

import com.cg.hotel.bean.Hotellll;
import com.cg.hotel.bean.HotelBook;

public interface Ihotel {
	
	long hotelBook(HotelBook bh);
	List<Hotellll> getHotels();
}
