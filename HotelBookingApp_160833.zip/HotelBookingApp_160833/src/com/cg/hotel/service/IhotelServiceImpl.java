package com.cg.hotel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hotel.bean.Hotellll;
import com.cg.hotel.bean.HotelBook;
import com.cg.hotel.dao.Ihotel;


@Service
@Transactional
public class IhotelServiceImpl implements IhotelService {
	@Autowired
	Ihotel ih;

	@Override
	public long hotelBook(HotelBook bh) {
		// TODO Auto-generated method stub
		return ih.hotelBook(bh);
	}
	@Override
	public List<Hotellll> getHotels() {
		// TODO Auto-generated method stub
		return ih.getHotels();
	}

}
