package com.cg.hotel.service;

import java.util.List;

import com.cg.hotel.bean.Hotellll;
import com.cg.hotel.bean.HotelBook;

public interface IhotelService {
	
	long hotelBook(HotelBook bh);
	List<Hotellll> getHotels();
}
