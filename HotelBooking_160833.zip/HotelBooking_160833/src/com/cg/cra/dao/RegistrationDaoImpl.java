package com.cg.cra.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.cra.entity.Hotel;
import com.cg.cra.entity.Registration;

@Repository
public class RegistrationDaoImpl implements RegistrationDao {
@PersistenceContext
	EntityManager em;
	
	@Override
	public long register(Registration reg) {
		em.persist(reg);
		return reg.getRegId();
	}

	@Override
	public List<Hotel> getAllHotels() {
		String jpql= "SELECT hotel  FROM hoteldetails hotel";
		TypedQuery<Hotel> query =  em.createQuery(jpql, Hotel.class);
		return query.getResultList();
	}

}
