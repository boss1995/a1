package com.cg.cra.service;

import java.util.List;

import com.cg.cra.entity.Hotel;
import com.cg.cra.entity.Registration;

public interface RegistrationService {
	
	long register(Registration reg);
	List<Hotel> getAllHotels();

}
