package com.cg.cra.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hoteldetails")
public class Hotel {
	@Id
	@Column(name="Id")
	private int Id;
	
	@Column(name="Name")
	private String Name;
	
	@Column(name="Rating")
	private String Rating;
	
	@Column(name="Rate")
	private String Rate;
	
	@Column(name="AvailableRooms")
	private String AvailableRooms;
	
	
	
	public Hotel() {
	
	}

	public int getId() {
		return Id;
	}

	public void setId(int Id) {
		this.Id = Id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}
	public String getRating() {
		return Rating;
	}

	public void setRating(String rating) {
		Rating = rating;
	}

	public String getRate() {
		return Rate;
	}

	public void setRate(String rate) {
		Rate = rate;
	}

	public String getAvailableRooms() {
		return AvailableRooms;
	}

	public void setAvailableRooms(String availableRooms) {
		AvailableRooms = availableRooms;
	}

}
