package com.cg.cra.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="bookingdetails")
public class Registration {
	@Id
	@Column(name="reg_id")
	@SequenceGenerator(name="Id_seq",sequenceName="seq_reg_id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="Id_seq")
	private Integer regId;
	@Column(name="customer_name")
	@NotEmpty(message="Customer name is mandatory")
	@Pattern(regexp="[A-Z][a-z]{2,}",message="Customer name should start with Capital letter and should contain min 3 char")
	private String customerName;
	@Column(name="No of rooms")
	@NotEmpty(message="Please enter number of rooms")
	@Pattern(regexp="[1-9]{1,}",message="no should be atleast 1 digit")
	private String noofrooms;
	
	@Column(name="id")
	private int id;
	
	@Column(name="amount")
	private int amount;
	
	public Registration() {
		
	}
	
	
	public String getnoofrooms() {
		return noofrooms;
	}


	public void setnoofrooms(String noofrooms) {
		this.noofrooms = noofrooms;
	}


	public int getamount() {
		return amount;
	}


	public void setamount(int amount) {
		amount = amount;
	}



	
	public Integer getRegId() {
		return regId;
	}
	public void setRegId(Integer regId) {
		this.regId = regId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getNoofrooms() {
		return noofrooms;
	}


	public void setNoofrooms(String noofrooms) {
		this.noofrooms = noofrooms;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}

	
	

}
